<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Support</h1>
    <form action="<?php echo e(route('support.send')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea name="message" id="message" rows="5" class="form-input" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send Message</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manny\Desktop\Project\Logistics-Delivery\resources\views/user/support-form.blade.php ENDPATH**/ ?>